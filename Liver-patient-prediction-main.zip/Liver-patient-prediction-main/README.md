# Liver patient prediction
A Review of Liver patient analyses method using machine learning
